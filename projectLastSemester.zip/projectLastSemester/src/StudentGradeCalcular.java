import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentGradeCalcular extends JFrame {

    private JTextField assignment1Field;
    private JTextField assignment2Field;
    private JTextField assignment3Field;
    private JButton calculateButton;
    private JLabel resultLabel;

    public StudentGradeCalcular() {
        createView();

        setTitle("Student Grade Calculator");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void createView() {
        JPanel panel = new JPanel();
        getContentPane().add(panel);

        JLabel assignment1Label = new JLabel("Assignment 1:");
        assignment1Field = new JTextField(5);
        panel.add(assignment1Label);
        panel.add(assignment1Field);

        JLabel assignment2Label = new JLabel("Assignment 2:");
        assignment2Field = new JTextField(5);
        panel.add(assignment2Label);
        panel.add(assignment2Field);

        JLabel assignment3Label = new JLabel("Assignment 3:");
        assignment3Field = new JTextField(5);
        panel.add(assignment3Label);
        panel.add(assignment3Field);

        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(new CalculateButtonActionListener());
        panel.add(calculateButton);

        resultLabel = new JLabel("Average: ");
        panel.add(resultLabel);
    }

    private class CalculateButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                double grade1 = Double.parseDouble(assignment1Field.getText());
                double grade2 = Double.parseDouble(assignment2Field.getText());
                double grade3 = Double.parseDouble(assignment3Field.getText());

                double average = (grade1 + grade2 + grade3) / 3;

                resultLabel.setText("Average: " + String.format("%.2f", average));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid grades.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new StudentGradeCalcular().setVisible(true);
            }
        });
    }
}
