import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TeacherLeaveForm extends JFrame {
    private JTextField teacherNameField;
    private JTextField employeeIDField;
    private JComboBox<String> leaveTypeComboBox;
    private JTextField startDateField;
    private JTextField endDateField;
    private JTextArea reasonArea;
    private JButton submitButton;
    private JTextArea displayArea;

    public TeacherLeaveForm() {
        createView();

        setTitle("Teacher Leave Form");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void createView() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 2, 10, 10));
        getContentPane().add(panel);

        JLabel teacherNameLabel = new JLabel("Teacher Name:");
        teacherNameField = new JTextField(20);
        panel.add(teacherNameLabel);
        panel.add(teacherNameField);

        JLabel employeeIDLabel = new JLabel("Employee ID:");
        employeeIDField = new JTextField(20);
        panel.add(employeeIDLabel);
        panel.add(employeeIDField);

        JLabel leaveTypeLabel = new JLabel("Leave Type:");
        leaveTypeComboBox = new JComboBox<>(new String[]{"Sick Leave", "Casual Leave", "Maternity Leave", "Other"});
        panel.add(leaveTypeLabel);
        panel.add(leaveTypeComboBox);

        JLabel startDateLabel = new JLabel("Start Date (YYYY-MM-DD):");
        startDateField = new JTextField(20);
        panel.add(startDateLabel);
        panel.add(startDateField);

        JLabel endDateLabel = new JLabel("End Date (YYYY-MM-DD):");
        endDateField = new JTextField(20);
        panel.add(endDateLabel);
        panel.add(endDateField);

        JLabel reasonLabel = new JLabel("Reason:");
        reasonArea = new JTextArea(3, 20);
        JScrollPane reasonScrollPane = new JScrollPane(reasonArea);
        panel.add(reasonLabel);
        panel.add(reasonScrollPane);

        submitButton = new JButton("Submit");
        submitButton.addActionListener(new SubmitButtonActionListener());
        panel.add(submitButton);

        displayArea = new JTextArea(10, 30);
        displayArea.setEditable(false);
        JScrollPane displayScrollPane = new JScrollPane(displayArea);
        panel.add(displayScrollPane);
    }

    private class SubmitButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String teacherName = teacherNameField.getText();
            String employeeID = employeeIDField.getText();
            String leaveType = (String) leaveTypeComboBox.getSelectedItem();
            String startDate = startDateField.getText();
            String endDate = endDateField.getText();
            String reason = reasonArea.getText();

            if (teacherName.isEmpty() || employeeID.isEmpty() || startDate.isEmpty() || endDate.isEmpty() || reason.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill out all fields.");
            } else {
                displayArea.setText("Leave Application Submitted\n" +
                        "----------------------------\n" +
                        "Teacher Name: " + teacherName + "\n" +
                        "Employee ID: " + employeeID + "\n" +
                        "Leave Type: " + leaveType + "\n" +
                        "Start Date: " + startDate + "\n" +
                        "End Date: " + endDate + "\n" +
                        "Reason: " + reason + "\n" +
                        "----------------------------\n" +
                        "Your leave application has been submitted.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TeacherLeaveForm().setVisible(true);
            }
        });
    }
}
