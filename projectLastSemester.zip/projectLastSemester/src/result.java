import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class result extends JFrame {
    private JTextField rollNumberField;
    private JButton searchButton;
    private JTextArea resultArea;

    // Sample data storage
    private Student[] students;

    public result() {
        createView();

        // Initialize sample data
        students = new Student[]{
                new Student("1001", "John Doe", "A"),
                new Student("1002", "Jane Smith", "B"),
                new Student("1003", "Mike Johnson", "C")
        };

        setTitle("Student Result Search");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void createView() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));
        getContentPane().add(panel);

        JLabel rollNumberLabel = new JLabel("Roll Number:");
        rollNumberField = new JTextField(20);
        panel.add(rollNumberLabel);
        panel.add(rollNumberField);

        searchButton = new JButton("Search");
        searchButton.addActionListener(new SearchButtonActionListener());
        panel.add(searchButton);

        resultArea = new JTextArea(5, 30);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        panel.add(scrollPane);
    }

    private class SearchButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String rollNumber = rollNumberField.getText();
            boolean found = false;
            for (Student student : students) {
                if (student.getRollNumber().equals(rollNumber)) {
                    resultArea.setText("Student Name: " + student.getName() + "\n" +
                            "Roll Number: " + student.getRollNumber() + "\n" +
                            "Grade: " + student.getGrade());
                    found = true;
                    break;
                }
            }
            if (!found) {
                resultArea.setText("No result found for Roll Number: " + rollNumber);
            }
        }
    }

    private class Student {
        private String rollNumber;
        private String name;
        private String grade;

        public Student(String rollNumber, String name, String grade) {
            this.rollNumber = rollNumber;
            this.name = name;
            this.grade = grade;
        }

        public String getRollNumber() {
            return rollNumber;
        }

        public String getName() {
            return name;
        }

        public String getGrade() {
            return grade;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new result().setVisible(true);
            }
        });
    }
}

