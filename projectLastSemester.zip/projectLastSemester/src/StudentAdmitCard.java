

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.*;

public class StudentAdmitCard extends JFrame implements Printable {
    private JTextField studentNameField;
    private JTextField rollNumberField;
    private JTextField examField;
    private JButton generateButton;
    private JButton printButton;
    private JTextArea admitCardArea;

    public StudentAdmitCard() {
        createView();

        setTitle("Student Admit Card Generator");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void createView() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 10, 10));
        getContentPane().add(panel);

        JLabel studentNameLabel = new JLabel("Student Name:");
        studentNameField = new JTextField(20);
        panel.add(studentNameLabel);
        panel.add(studentNameField);

        JLabel rollNumberLabel = new JLabel("Roll Number:");
        rollNumberField = new JTextField(20);
        panel.add(rollNumberLabel);
        panel.add(rollNumberField);

        JLabel examLabel = new JLabel("Exam:");
        examField = new JTextField(20);
        panel.add(examLabel);
        panel.add(examField);

        generateButton = new JButton("Generate Admit Card");
        generateButton.addActionListener(new GenerateButtonActionListener());
        panel.add(generateButton);

        printButton = new JButton("Print Admit Card");
        printButton.addActionListener(new PrintButtonActionListener());
        panel.add(printButton);

        admitCardArea = new JTextArea(10, 30);
        admitCardArea.setEditable(false);
        admitCardArea.setBackground(Color.PINK);
        JScrollPane scrollPane = new JScrollPane(admitCardArea);
        panel.add(scrollPane);
    }

    private class GenerateButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String studentName = studentNameField.getText();
            String rollNumber = rollNumberField.getText();
            String exam = examField.getText();

            if (studentName.isEmpty() || rollNumber.isEmpty() || exam.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill out all fields.");
            } else {
                admitCardArea.setText("******************************\n" +
                        "         ADMIT CARD\n" +
                        "******************************\n" +
                        "Student Name: " + studentName + "\n" +
                        "Roll Number: " + rollNumber + "\n" +
                        "Exam: " + exam + "\n" +
                        "******************************");
            }
        }
    }

    private class PrintButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            PrinterJob printerJob = PrinterJob.getPrinterJob();
            printerJob.setPrintable(StudentAdmitCard.this);

            boolean doPrint = printerJob.printDialog();
            if (doPrint) {
                try {
                    printerJob.print();
                } catch (PrinterException ex) {
                    JOptionPane.showMessageDialog(null, "Printing failed: " + ex.getMessage());
                }
            }
        }
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int pageIndex) throws PrinterException {
        if (pageIndex > 0) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        // Print the content of the admit card area
        admitCardArea.printAll(g);

        return PAGE_EXISTS;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new StudentAdmitCard().setVisible(true);
            }
        });
    }
}
