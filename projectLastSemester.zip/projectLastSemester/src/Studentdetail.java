import javax.swing.*;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import  javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Studentdetail extends JFrame implements ActionListener {
    public JTable table;
    public JScrollPane scroll;
    public DefaultTableModel model;
    public Container c;
    public JLabel titleLabel, fnLabel, InLabel, phoneLabel, gpaLabel;
    public JTextField fnTf, inTf, phoneTf, gpaTf;
    public JButton addButton, updateButton, deleteButton, clearButton;
    public String[] columns = {"first name", "ROLL NUMBER", "phone number", "gpa"};
    public String[] rows = new String[4];

    Studentdetail() {
        component();
    }


    public void component() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(770, 790);
        this.setLocationRelativeTo(null);
        this.setTitle("Student Details");


        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);


        Font font = new Font("Arial", Font.BOLD, 16);

        titleLabel = new JLabel("Student Details Information");
        titleLabel.setFont(font);
        titleLabel.setBounds(140, 10, 250, 50);
        c.add(titleLabel);

        fnLabel = new JLabel(" Name");
        fnLabel.setBounds(10, 80, 140, 30);
        fnLabel.setFont(font);
        c.add(fnLabel);

        fnTf = new JTextField();
        fnTf.setBounds(110, 80, 200, 30);
        fnTf.setFont(font);
        c.add(fnTf);


        addButton = new JButton("add");
        addButton.setBounds(400, 80, 100, 30);
        addButton.setFont(font);
        c.add(addButton);


        InLabel = new JLabel("Roll number");
        InLabel.setBounds(10, 130, 150, 30);
        InLabel.setFont(font);
        c.add(InLabel);

        inTf = new JTextField();
        inTf.setBounds(110, 130, 150, 30);
        inTf.setFont(font);
        c.add(inTf);


        updateButton = new JButton("Update");
        updateButton.setBounds(400, 130, 100, 30);
        updateButton.setFont(font);
        c.add(updateButton);

        phoneLabel = new JLabel("phone");
        phoneLabel.setBounds(10, 180, 150, 30);
        phoneLabel.setFont(font);
        c.add(phoneLabel);

        phoneTf = new JTextField();
        phoneTf.setBounds(110, 180, 200, 30);
        phoneTf.setFont(font);
        c.add(phoneTf);

        deleteButton = new JButton("delete");
        deleteButton.setBounds(400, 180, 100, 30);
        deleteButton.setFont(font);
        c.add(deleteButton);


        gpaLabel = new JLabel("CGPA");
        gpaLabel.setBounds(10, 230, 150, 30);
        gpaLabel.setFont(font);
        c.add(gpaLabel);

        gpaTf = new JTextField();
        gpaTf.setBounds(110, 230, 200, 30);
        gpaTf.setFont(font);
        c.add(gpaTf);

        clearButton = new JButton("Clear");
        clearButton.setBounds(400, 230, 100, 30);
        clearButton.setFont(font);
        c.add(clearButton);


        table = new JTable();
        model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
        table.setModel(model);
        table.setFont(font);
        table.setSelectionBackground(Color.orange);
        table.setBackground(Color.green);
        table.setRowHeight(30);

        scroll = new JScrollPane(table);
        scroll.setBounds(10, 360, 740, 265);
        c.add(scroll);

        addButton.addActionListener(this);
        clearButton.addActionListener(this);
        deleteButton.addActionListener(this);
        updateButton.addActionListener(this);
    }

    public static void main(String[] args) {
        Studentdetail frame = new Studentdetail();
        frame.setVisible(true);
    }

    /**
     * Invoked when an action occurs.
     *
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            rows[0] = fnTf.getText();
            rows[1] = inTf.getText();
            rows[2] = phoneTf.getText();
            rows[3] = gpaTf.getText();
            model.addRow(rows);
        } else if (e.getSource() == clearButton) {
            fnTf.setText("");
            inTf.setText("");
            phoneTf.setText("");
            gpaTf.setText("");
        }
        else if(e.getSource()==deleteButton)
        {
            int numberofRow=table.getSelectedRow();
            if(numberofRow>=0)
            {
                model.removeRow(numberofRow);
            }
            else {
                JOptionPane.showMessageDialog(null,"no row has found");
            }
        }
        else if(e.getSource()==updateButton)
        {
          int numberofrow=table.getSelectedRow();
          String name=fnTf.getText();
          String roll=inTf.getText();
          String PHONE=phoneTf.getText();
          String gpa=gpaTf.getText();

          model.setValueAt(name,numberofrow,0);
            model.setValueAt(roll,numberofrow,1);
            model.setValueAt(PHONE,numberofrow,2);
            model.setValueAt(gpa,numberofrow,3);


        }
    }
}


