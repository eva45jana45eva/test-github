import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Attendance extends JFrame {

    private JTextField studentNameField;
    private JRadioButton presentRadioButton;
    private JRadioButton absentRadioButton;
    private JButton submitButton;
    private JTextArea displayArea;

    public Attendance() {
        createView();

        setTitle("Student Attendance Form");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void createView() {
        JPanel panel = new JPanel();
        getContentPane().add(panel);

        JLabel nameLabel = new JLabel("Student Name:");
        studentNameField = new JTextField(20);
        panel.add(nameLabel);
        panel.add(studentNameField);

        presentRadioButton = new JRadioButton("Present");
        absentRadioButton = new JRadioButton("Absent");
        ButtonGroup group = new ButtonGroup();
        group.add(presentRadioButton);
        group.add(absentRadioButton);

        panel.add(presentRadioButton);
        panel.add(absentRadioButton);

        submitButton = new JButton("Submit");
        submitButton.addActionListener(new SubmitButtonActionListener());
        panel.add(submitButton);

        displayArea = new JTextArea(10, 30);
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        panel.add(scrollPane);
    }

    private class SubmitButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String studentName = studentNameField.getText();
            String attendanceStatus = presentRadioButton.isSelected() ? "Present" : "Absent";

            if (studentName.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a student name.");
            } else {
                displayArea.append("Student: " + studentName + " - Attendance: " + attendanceStatus + "\n");
                studentNameField.setText("");
                presentRadioButton.setSelected(false);
                absentRadioButton.setSelected(false);
            }
        }
    }

    public static void main(String[] args) {

        new Attendance().setVisible(true);
    }
}
