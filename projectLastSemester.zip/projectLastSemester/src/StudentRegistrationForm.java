import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentRegistrationForm extends JFrame {
    private JTextField studentNameField;
    private JTextField studentIdField;
    private JTextField dobField;
    private JTextField emailField;
    private JTextField contactField;
    private JButton registerButton;
    private JButton clearButton;
    private JTextArea resultArea;

    public StudentRegistrationForm() {
        createView();

        setTitle("Student Registration Form");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 700);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void createView() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2, 10, 10));
        getContentPane().add(panel);

        JLabel studentNameLabel = new JLabel("Student Name:");
        studentNameField = new JTextField(20);
        panel.add(studentNameLabel);
        panel.add(studentNameField);

        JLabel studentIdLabel = new JLabel("Student ID:");
        studentIdField = new JTextField(20);
        panel.add(studentIdLabel);
        panel.add(studentIdField);

        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        dobField = new JTextField(20);
        panel.add(dobLabel);
        panel.add(dobField);

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField(20);
        panel.add(emailLabel);
        panel.add(emailField);

        JLabel contactLabel = new JLabel("Contact Number:");
        contactField = new JTextField(20);
        panel.add(contactLabel);
        panel.add(contactField);

        registerButton = new JButton("Register");
        registerButton.addActionListener(new RegisterButtonActionListener());
        panel.add(registerButton);

        clearButton = new JButton("Clear");
        clearButton.addActionListener(new ClearButtonActionListener());
        panel.add(clearButton);

        resultArea = new JTextArea(20, 30);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        panel.add(scrollPane);
    }

    private class RegisterButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String studentName = studentNameField.getText();
            String studentId = studentIdField.getText();
            String dob = dobField.getText();
            String email = emailField.getText();
            String contact = contactField.getText();

            if (studentName.isEmpty() || studentId.isEmpty() || dob.isEmpty() || email.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill out all fields.");
            } else {
                resultArea.setText("Student Registration Successful\n" +
                        "-------------------------------\n" +
                        "Student Name: " + studentName + "\n" +
                        "Student ID: " + studentId + "\n" +
                        "Date of Birth: " + dob + "\n" +
                        "Email: " + email + "\n" +
                        "Contact Number: " + contact);
            }
        }
    }

    private class ClearButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            studentNameField.setText("");
            studentIdField.setText("");
            dobField.setText("");
            emailField.setText("");
            contactField.setText("");
            resultArea.setText("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new StudentRegistrationForm().setVisible(true);
            }
        });
    }
}
